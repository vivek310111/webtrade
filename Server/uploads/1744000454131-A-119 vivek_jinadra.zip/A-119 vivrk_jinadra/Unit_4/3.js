var a=10;
var b=30;

document.write("<h1> additon of two number :"+(a+b)+"</h1>");
document.write("<hr>");
document.write("<h1> substiction of two number :"+(a-b)+"</h1>");
document.write("<hr>");
document.write("<h1> multification of two number :"+(a*b)+"</h1>");
document.write("<hr>");
document.write("<h1> divided of two number :"+(a/b)+"</h1>")
