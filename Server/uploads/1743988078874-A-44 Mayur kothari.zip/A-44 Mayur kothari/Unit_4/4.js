var a=60;
var b=40;

document.write(a < 10 && b < 15);
document.write("<br>");
document.write("<br>");
document.write(a < 10 || b < 15 );
 