var a = prompt("Please Enter Km ");
var b=(a * 1000);
document.write((a) + "  Km equals to    "+ (b) + "  meters.");