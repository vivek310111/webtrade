import React from "react"
import Navbar from "../components/Navbar"
import Footer from "../components/Footer"
import "../assets/about.css"

export default function About() {
    return(
        <>
        <Navbar />
        <div className="about-title">
        <h1>About page goes here !!</h1>
        </div>
        <Footer />
        </>
        
    )
}