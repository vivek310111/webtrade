import React from "react";
import "../assets/cart.css";
import productImage from "../assets/images/image.png";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";


const Cart = () => {
  return (
    <>
    <Navbar />
    <div className="cart-container">
    <h2 className="cart-title">Cart</h2>
      {/* Cart Table */}
      <div className="cart-table">
        <div className="cart-header">
          <span>Product</span>
          <span>Price</span>
          <span>Subtotal</span>
        </div>

        {/* Cart Item */}
      <div className="cart-item">
            <img src={productImage} alt="" className="product-image" />
          <div className="product-info">
            <div>
              <p className="product-name">Simple Responsive Website</p>
              <p className="product-desc">HTML, CSS, JAVASCRIPT</p>
            </div>
          </div>
          <span className="product-price">₹25,000.00</span>
          <span className="product-subtotal">₹25,000.00</span>
          <span className="remove-item">🗑️</span>
        </div>
      </div>

      {/* Order Summary */}
      <div className="order-summary">
        <h3>Order Summary</h3>
        <div className="summary-details">
          <p>Subtotal <span>₹25,000.00</span></p>
          <p className="total">Total <span>₹25,000.00</span></p>
        </div>
        <button className="checkout-btn">Check Out</button>
      </div>
    </div>
    <Footer />
    </>
  );
};

export default Cart;
