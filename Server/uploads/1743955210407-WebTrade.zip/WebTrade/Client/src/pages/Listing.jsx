import React from 'react'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import '../assets/listing.css'

export default function listing() {
  return (
    <>
    <Navbar />
    <div className='listing-div'>
      <h1>
        Listing Page Goes Here !!
        </h1>
      </div>
    <Footer />
    </>
  )
}
