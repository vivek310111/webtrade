import React from 'react'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import '../assets/home.css'

export default function home() {
  return (
    <>
    <Navbar />
    <div className='home'>
      <h1>
        Home page is Under Development!
      </h1>
    </div>
    <Footer />
    </>
  )
}
