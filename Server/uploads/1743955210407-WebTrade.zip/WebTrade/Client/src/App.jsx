import './App.css'
import { Routes,Route} from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from '../src/pages/Home'
import Login from './pages/Login'
import Register from './pages/register'
import Listing from './pages/Listing'
import axios from 'axios'
import {Toaster} from 'react-hot-toast'
import Cart from './pages/Cart'
import ContactForm from './pages/Contact'
import Pricing from './pages/Pricing'
import About from './pages/About'

axios.defaults.baseURL = 'http://localhost:8000'
axios.defaults.withCredentials = true

function App() {
  return (
    <>
    <Toaster position='bottom-center' toastOptions={{duration: 2000,  
      style: {
      background: '#777',
      color: '#000000',
      animation: 'custom-enter 1s ease',
      fontFamily:'poppins',
      fontWeight:'500',
     
    }
    }}/>
    <Routes>
      <Route path='/' element={<Register />} />
      <Route path='/listing' element={<Listing />} />  
      <Route path='/login' element={<Login />} />
      <Route path='/home' element={<Home />} />
      <Route path='/cart' element={<Cart />} />
      <Route path='/contact' element={<ContactForm />} />
      <Route path='/pricing' element={<Pricing />} />
      <Route path='/about' element={<About />}/>

      </Routes>
    </>
  )
}

export default App
