import { Link } from "react-router-dom"
import react from 'react'
import '../components/navbar.css'

export default function Navbar() {
  return( 
    <>
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-left">
          <Link to='/home'  className="logo">
          <img src="../src/assets/images/logo.png" alt="WEB TRADE" ></img>
          </Link>
        </div>
        <div className="navbar-right">
          <ul className="navbar-links">
            <li className="navbar-item">
              <Link to='/home' className="navbar-link">Home</Link>
            </li>
            <li className="navbar-item">
              <Link to='/pricing' className="navbar-link">Pricing</Link>
            </li>
            <li className="navbar-item">
              <Link to='/about' className="navbar-link">About</Link>
            </li>
            <li className="navbar-item">
              <Link to='/contact' className="navbar-link">Contact</Link>
            </li>
          </ul>
          <div className="navbar-icons">
              <Link to='/profile' className="navbar-icon">
              <img src="../src/assets/images/profile.png" alt="" /> 
              </Link>
              <Link to='/cart' className="navbar-icon">
              <img src="../src/assets/images/cart.png" alt="" />
              </Link>
          </div>
        </div>
      </div>
    </nav>
</>  
  )
}
